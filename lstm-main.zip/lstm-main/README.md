git clone https://github.com/pragnyanalabola/lstm.git

cd lstm

pip install streamlit yfinance tensorflow numpy pandas scikit-learn matplotlib

streamlit run lstm.py
